<!DOCTYPE html>


<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Webcenter Technologies, Inc </title>

  <!-- Bootstrap -->
  <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/style2.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('css/flexslider.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('icons/css/ionicons.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('icons/css/simple-line-icons.css')); ?>" rel="stylesheet" type="text/css">

  <!--revolution slider setting css-->
  <link href="<?php echo e(asset('rs-plugin/css/settings.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/prettyPhoto.css')); ?>" rel="stylesheet" type="text/css" />
  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="80">


  <!-- Static navbar -->
  <nav class="navbar navbar-default navbar-fixed-top before-color" style="background-color: white;">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
          aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand alo" style="font-size: 20px;">Webcenter Technologies</a>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right scroll-to">
          <li class="active"><a href="/">Home</a></li>
          <li><a href="/#about">About</a></li>
          <li><a href="/#services">Services</a></li>
          <li><a href="/#work">Work</a></li>
          
          
          
          <li><a href="/#contact">Contact</a></li>
          <li><a href="/projects">Project </a></li>

        </ul>
      </div><!--/.nav-collapse -->
    </div><!--/.container-fluid -->
  </nav>

  <section id="about" class="section-padding">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 col-sm-offset-2 text-center">
          <div class="section-title">
            <h1>Our <span class="colored-text">Projects</span> </h1>
            <span class="border-line"></span>

          </div>
        </div>
      </div><!-- title row end-->

      <div class="row">
        <div class="col-sm-12 margin-bottom30">
          <div class="feature-icon-wrap clearfix">
            <div class="features-text-right">
              <h3>PT. WEBCENTER TECHNOLOGIES, INC.</h3>
              <p>
                Our company has produced a range of innovative applications that span various fields, demonstrating our
                commitment to delivering cutting-edge technological solutions. Each product we develop reflects our
                dedication to providing a superior user experience and adding value to our customers. These applications
                not only cover a broad spectrum in terms of functionality but are also designed with a priority on
                security, performance, and innovation, illustrating our technical expertise and strategic vision in
                delivering relevant and reliable solutions in the ever-evolving market.

              </p>
            </div>

            <div class="container">
              <div class="row">
                <div class="list-group" style="padding-left: 50px; padding-right: 50px;">
                  <div class="text-justify" style="text-align: justify; ">
                    <div class="list-group-item list-group-item-action ">
                      <OL><br>
                        <LI>PT. Dwi Laras Sejati <br>Proyek Pembuatan Situs Portal Informasi Kesehatan Departemen
                          Kesehatan.  (2000)<br><br>
                        <LI>Balatbangsos Departemen Sosial<br>Proyek Pembuatan Situs Portal Informasi Sosial
                         (2000)<br><br>
                        <LI>Koperasi Karyawan dan Jamaah Masjid Istiqlal<br>Proyek Pembuatan Situs Portal Keagamaan
                           (2000)<br><br>
                        <LI>Pemda Bantul – Yogyakarta<br>Proyek Situs Pemerintahan  <br>Sistem
                          Informasi Kependudukan (SIMDUK).<br>Sistem Informasi Manajemen Unit Pelayana Satu Atap (SIM
                          UPSTA)<br><br>
                        <LI>PT. Dwi Laras Sejati<br>Proyek Pembuatan Situs Portal Usaha Industri Kerajinan PEMDA
                          Kabupaten Bantul(2000)<br><br>
                        <LI>PLN (Persero) P3B<br>Penyaluran Dan Pusat Pengatur Beban Jawa – Bali.<br>IT Trainning :
                          Linux System & Mail System Administration (2001)<br><br>
                        <LI>PLN (Persero) P3B <br>Penyaluran Dan Pusat Pengatur Beban Jawa – Bali.<br>Proyek Pembuatan
                          Mail System, Instalasi Server dan Mail Virus Guard (2001)<br><br>
                        <LI>PLN (Persero) P3B<br>Penyaluran Dan Pusat Pengatur Beban Jawa – Bali.<br>IT Trainning : Web
                          Mastering dan PHP dengan studi kasus:<br> (2001)<br><br>
                        <LI>PT. PLN (Persero) P3B<br>Aplikasi Grafik Pembebanan dan Kesiapan Pembangkit Jawa - Bali
                          (Neraca Daya Jawa - Bali), Unit Bidding Operation System
                          (UBOS)<br> (2002)<br><br>
                        <LI>Pertiwi Group <br>Pembuatan Web Company Pertiwi
                          Group dan Sistem Informasi Perguruan Tinggi STBA PERTIWI. (Pembuatan Sistem Registrasi Online,
                          Sistem Akademik, SDM dan Report Keuangan). (2002)<br><br>
                        <LI>PT. Kompassindo (Advertising & Event Organizer)<br>Pembuatan Web Company <br><br>
                        <LI>PT. Impressions (Pusat Kebugaran dan Kecantikan)<br>Pembuatan Web Company
                         <br><br>
                        <LI>Direktorat PRS Korban NAPZA Departemen Sosial R.I<br>Proyek Pembuatan Situs Portal Informasi
                          Seputar NAPZA (2003)<br><br>
                        <LI>PLN (Persero) Unit Bisnis Strategis<br>Penyaluran Dan Pusat Pengatur Beban Jawa –
                          Bali.<br>IT Trainning : Database MS SQL Server 2000 dengan studi kasus: Replikasi Data SDM P3B
                          (2003)<br><br>
                        <LI>PLN (Persero) Unit Bisnis Strategis<br>Penyaluran Dan Pusat Pengatur Beban Jawa –
                          Bali.<br>IT Trainning : Database Oracle for Linux (2003)<br><br>
                        <LI>PLN (Persero) Unit Bisnis Strategis<br>Penyaluran Dan Pusat Pengatur Beban Jawa –
                          Bali.<br>IT Trainning : C and Perl Programming (2003)<br> <br>
                        <LI>PLN (Persero) P3B<br>Penyaluran Dan Pusat Pengatur Beban Jawa – Bali.<br>IT Trainning :
                          Securing & Optimizing Your Network Using Linux dengan studi kasus : Membuat Firewall dan
                          Bandwidth Management di P3B (2004)<br> <br>
                        <LI>PLN (Persero) P3B<br>Penyaluran Dan Pusat Pengatur Beban Jawa – Bali.<br>IT Trainning :
                          Foxpro dan PHP dengan Studi kasus : pembuatan aplikasi Sistem Informasi Manajemen Pegawai
                          (SIPEG) dengan Foxpro di aplikasikan ke Web. (2004)<br><br>
                        <LI>Kementerian Kebudayaan dan Pariwisata <br>Proyek Sistem Informasi Pemasaran Budaya dan
                          Pariwisata<br>(2004)<br><br>
                        <LI>PLN (Persero) P3B<br>Aplikasi HDKS (Harian Deklarasi Ketidaksiapan Pembangkit)<br>Proyek
                          Pembuatan Sistem Pelaporan dan konfirmasi Ketidaksiapan Pembangkit pada Sistem Jawa – Bali
                          (2004)<br><br>
                        <LI>PLN (Persero) P3B<br>Aplikasi LOGSHEET<br>Proyek Pembuatan Database Pencatatan Sistem
                          Operasi Kontrol Jawa - Bali (2004)<br><br><br>
                        <LI>Pemerintah Kotamadya Jakarta Pusat (BAPEKODYA)<br>Proyek Pembuatan Informasi Berbasis
                          Internet (2004)<br><br>
                        <LI>SMA NEGERI 1 Jakarta Pusat<br><br>
                        <LI>LAPAN (Lembaga Penerbangan dan Antariksa Nasional)<br>Sistem Management Informasi dan Situs
                          Kehumasan HUMASMAGAN<br> (2005)<br><br>
                        <LI>PT. PLN (Persero) P3B<br>Sistem Informasi Material Gudang/Inventory Control (2005)<br><br>
                        <LI>PT. PLN (Persero) P3B<br>Web P3B Jawa Bali  (2006)<br><br>
                        <LI>PT. PLN (Persero) P3B<br>Aplikasi SPPD (Surat Perintah Perjalanan Dinas) (2006)<br><br>
                        <LI>PT. PLN (Persero) P3B<br>GAIS (Generation Availibility Information System)
                          (2006)<br>Aplikasi Report Kinerja Pembangkit Jawa-Bali Indonesia<br><br>
                        <LI>PT. PLN (Persero) P3B UBOS<br>Aplikasi Pemeliharaan Jalur 500kV (2006)<br>Aplikasi
                          Penjadwalan Pemeliharaan Peralatan Penyaluran 500kV Jawa Bali<br><br>
                        <LI>PT. PLN (Persero) P3B Humas<br>FrontDesk (2006)<br><br>
                        <LI>PT. PLN (Persero) P3B USEM Setelmen<br>Data Capture Meter Q1000 & JEMSTAR, Linux & Windows
                          (2006)<br>AMR (Automatic Meter Reading)<br><br>
                        <LI>PT. PLN (Persero) P3B USEM Setelmen<br>Neraca Energi (2006)<br>Aplikasi Report Penerimaan &
                          Pengiriman Energi Jawa-Bali Indonesia<br><br>
                        <LI>PT. PLN (Persero) P3B USEM Setelmen<br>PSA (Power Sales Agreement) (2006)<br>Aplikasi
                          Perhitungan dan Reporting Transaksi Energi Listrik dgn PLN Distribusi Jawa-Bali<br><br>
                        <LI>PT. PLN (Persero) P3B Sumatera<br>Aplikasi Kompetensi Pegawai (2006)<br><br>
                        <LI>PT. PLN (Persero) P3B USEM (Unit Setelmen)<br>Data Capture Meter NEXUS, Linux & Windows
                          (2007)<br>AMR (Automatic Meter Reading)<br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Teknik<br>Interface Material Gudang (2007)<br>Interfacing Data
                          Material Gudang dari SAP (ERP)<br><br>
                        <LI>PT. PLN (Persero) P3B Keuangan & Niaga<br>Monitoring SKI (2007)<br>Aplikasi Monitoring
                          Anggaran Investasi <br><br>
                        <LI>PT. PLN (Persero) P3B Region & UBOS (Bidang Operasi)<br>Aplikasi Pemeliharaan Jalur 150kV &
                          70kV (2007)<br>Aplikasi Penjadwalan Pemeliharaan Peralatan Penyaluran 150kV & 70kV Jawa
                          Bali<br><br>
                        <LI>PT. PLN (Persero) P3B UBOS (Bidang Operasi)<br>LogSheet Modul CatKit & Mutasi
                          (2007)<br>Aplikasi LogSheet Modul Log Pembangkitan & Report Jawa Bali<br>Pencatatan Pembebanan
                          Pembangkitan IBT, Penyaluran, Emergensi, Mutasi, Padam<br><br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang SDM<br>Aplikasi Mesin Absen Daemon (2007)<br><br>
                        <LI>PT. PLN (Persero) P3B<br>Aplikasi SMS Reporting (2007)<br>Aplikasi SMS, SMS Reporting dan
                          SMS Gateway<br>Pembebanan Pembangkitan, Konsumen, Report Keuangan dan Anggaran<br><br>
                        <LI>PT. PLN (Persero) P3B Keuangan & Niaga<br>Monitoring Progress Fisik SKI (2007)<br>Aplikasi
                          Monitoring Progress Anggaran Investasi <br><br>
                        <LI>PT. PLN (Persero) P3B Keuangan & Niaga<br>Aplikasi RAB (Anggaran Operasi) (2007)<br>Aplikasi
                          Perencanaan dan Monitoring Anggaran Operasi<br><br>
                        <LI>PT. PLN (Persero) P3B<br>Mail System (2007)<br>Upgrade dan Penambahan Fiture WebMail, Mail
                          Server Installation<br>Antivirus, AntiSpam.<br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Operasi (BOPS)<br>Aplikasi Reporting Index Kinerja Pembangkit
                          (GAIS) standart NERC (2007 ~ 2008)<br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Operasi (BOPS)<br>Aplikasi Susut Subsystem (2007)<br>Aplikasi
                          Perhitungan Susut Subsystem, Transfer dan IBT, Energi Kirim dan Terima.<br>-----<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali<br>Aplikasi AMR Automatic Meter Reader Jawa Bali
                          (2007)<br>AMR Pembangkitan - PLN Distribusi - Meter Internal<br><br>
                        <LI>PT. PLN (Persero)<br>Aplikasi SIMKP (2008)<br>Aplikasi Penilaian Kinerja Pegawai PLN
                          Nasional<br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Operasi (BOPS)<br>DATA CAPTURE METER Jemstar (2008)<br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Operasi (BOPS)<br>DATA CAPTURE METER Q1000 (2008)<br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Operasi (BOPS)<br>DATA CAPTURE METER ION8600 (2008)<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali<br>Aplikasi Meter Management (2009)<br>Aplikasi Menejemen
                          Meter - Historical dan Kalibrasi Meter<br><br>
                        <LI>PT. ANGKASA PURA<br>Aplikasi Knowledge Center (2009)<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali<br>Aplikasi TLSK (2009)<br>Aplikasi Tata Laksana Surat dan
                          Kearsipan<br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Operasi (BOPS)<br>DATA CAPTURE METER SL7000 (2009)<br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Operasi (BOPS)<br>DATA CAPTURE METER ABBA1R (2009)<br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Operasi (BOPS)<br>DATA CAPTURE METER Q220 (2009)<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali<br>Installasi Linux Cluster 12 Server (2009)<br>Installasi
                          Linux Cluster - SIMKP Nasional <br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Operasi (BOPS)<br>Installation Converter (2009)<br>Installation
                          Converter MOXA I<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali<br>Aplikasi GIS - Asset Map P3B (2009)<br>Aplikasi Pemetaan
                          Asset PLN P3B<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang SDM<br>Aplikasi Absensi P3B (2010)<br>Sistem Absen
                          dan Report Absen Karyawan<br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Operasi (BOPS)<br>Aplikasi Dashboard Pembangkitan
                          (2010)<br>Aplikasi Dashboard Pembangkitan<br><br>
                        <LI>PT. PLN (Persero) P3B Bidang Operasi (BOPS)<br>Installation Converter (2010)<br>Installation
                          Converter MOXA II<br>Installation Converter MOXA III<br><br>
                        <LI>PT. PLN (Persero)<br>Aplikasi SMUK PLN (2010)<br>Aplikasi Sistem Management Unjuk Kerja
                          Pegawai PLN<br><br>
                        <LI>PT Indonesia Comnets Plus (ICON+)<br>MONITORING KONTRAK ICON (2010)<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Teknik<br>Aplikasi TINGKAT MUTU PELAYANAN (TMP)
                          (2010)<br>Aplikasi Estimasi Waktu Pekerjaan Pemeliharaan Material<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Teknik<br>Aplikasi WORKFLOW SKI (2010)<br>Aplikasi
                          Monitoring SKI P3B<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Teknik<br>Aplikasi SINGLE IDENTITY DATABASE (PST)
                          (2010)<br>Aplikasi SINGLE IDENTITY DATABASE<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Operasi (BOPS)<br>Aplikasi PPA P3B Jawa Bali
                          (2010)<br>Aplikasi Pembelian Energi dari Pembangkit<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Operasi (BOPS)<br>Aplikasi HDKP SETTLEMENT
                          (2010)<br>Aplikasi HDKP SETTLEMENT Pembangkitan<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Operasi (BOPS)<br>Aplikasi SUPERVISORY REPORT
                          (2011)<br>SUPERVISORY REPORT Sistem Pembangkitan<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Operasi (BOPS)<br>Aplikasi Evaluasi Operasi Sistem
                          Jawa bali (2011)<br>Sistem Pembangkitan<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Operasi (BOPS)<br>Aplikasi ATTB DAN MATERIAL BURSA -
                          INVENTORY (2011)<br><br>
                        <LI>PT. PLN (Persero)<br>Aplikasi TALENT POOL (SIMKP+SMUK+SAP) (2011)<br>Aplikasi Talent
                          Managemen PLN<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Operasi (BOPS)<br>Aplikasi LFC + FREE GOVERNOR
                          (2011)<br>Aplikasi Perhitungan LFC + FREE GOVERNOR Pembangkitan se Jawa Bali<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Operasi (BOPS)<br>Aplikasi MARGINAL COST
                          (2011)<br>Aplikasi Perhitungan MARGINAL COST Pembangkitan se Jawa Bali<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Operasi (BOPS)<br>Aplikasi Evaluasi Operasi Sistem
                          Jawa bali (2011)<br>Sistem Penyaluran<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Menegemen Asset (BOPS)<br>Aplikasi Uji Peralatan
                          (2012)<br>Uji Peralatan GAS pada Gardu Induk GIS<br>- GAS (TEIMS PORTABLE PM)<br>- SF6
                          ANALYZER<br>- RH SYSTEM MODEL 973<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Menegemen Asset (BOPS)<br>MONITORING VISUAL CBM MAP
                          (2012)<br>Aplikasi Pemetaan Monitoring Anomali <br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Asset<br>Aplikasi Job Number (2012)<br>Aplikasi SOP
                          Kerja - Penggantian Peralatan<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Keuangan<br>Aplikasi PMO - Project Management
                          (2013)<br>Aplikasi Monitoring Project<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Pemeliharaan<br>Aplikasi SKK (2013)<br>Aplikasi
                          Monitoring Kontrak (Surat Kuasa Kerja)<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Sub Bidang TI<br>Hotspot P3B Jawa Bali (2013)<br>Hotspot
                          WIFI Karyawan, Member and Guest <br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang SDM<br>Aplikasi SILAT (2013)<br>Aplikasi Sistem
                          Management Diklat Karyawan<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Bidang Keuangan<br>Aplikasi PPFA (2013)<br>Aplikasi SMS
                          Service Reminder Pembayaran Karyawan<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali APP Bogor<br>Aplikasi PBJ (2013)<br>Aplikasi Workflow
                          Pengadaan Barang dan Jasa <br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali Sub Bidang TI<br>Optical Fiber Network Installation and
                          Switch Configuration (2013)<br>Cisco Switch 1Gig and 10Gig Network Installation<br><br>
                        <LI>PLN (Persero) P3B Jawa Bali <br>PENGEMBANGAN JALUR EAM - TRANSMISI (2014)<br><br>
                        <LI>PLN (Persero) P3B Jawa Bali <br>DATA STORAGE ASSESMENT (2014)<br><br>
                        <LI>PLN (Persero) P3B Jawa Bali <br>HARGA PERKIRAAN ENGINEERING (HPE) (2014)<br><br>
                        <LI>PLN (Persero) P3B Jawa Bali <br>INSTALASI SISTEM DNS UNTUK SERVER (2014)<br><br>
                        <LI>PLN (Persero) P3B Jawa Bali<br>INTERFACING EAM UNTUK APLIKASI GIS (2014)<br><br>
                        <LI>PLN (Persero) <br>APLIKASI MONITORING KEUANGAN SERIKAT PEKERJA SP PLN (2014)<br><br>
                        <LI>PLN (Persero) <br>APLIKASI BISNIS PROSES FRAMEWORK (2014)<br><br>
                        <LI>PLN (Persero) AP2B Kaltim<br>INTEGRASI PEMBACAAN KWH METER AP2B Kaltim(2014)<br><br>
                        <LI>PLN (Persero) P3B Jawa Bali<br>SISTEM LOAD BALANCER UNTUK APLIKASI NERACA ENERGI
                          (2014)<br><br>
                        <LI>PLN (Persero) P3B Jawa Bali<br>APLIKASI ANCILLARY SERVICES (2014)<br><br>
                        <LI>PLN (Persero) P3B Jawa Bali APP BOGOR<br>APLIKASI SOFTWARE MONITORING PENGADAAN BARANG DAN
                          JASA PLN APP BOGOR (2014)<br><br>
                        <LI>PLN (Persero) P3B Jawa Bali<br>APLIKASI PERJALANAN DINAS (2014)<br><br>
                        <LI> PT. PLN (Persero) P3B Jawa-Bali<br>INSTALASI SERVER MASTER STATION AMR (2015)<br><br>
                        <LI>PT. PLN (Persero) AP2B Kaltim<br>12 CHANNEL AMR PT PLN (PERSERO) AP2B SISTEM KALTIM
                          (2015)<br><br>
                        <LI> PT. PLN (Persero) P3B Jawa-Bali<br>PENGEMBANGAN APLIKASI HPE (2015)<br><br>
                        <LI> PT. PLN (Persero) P3B Sumatera<br>APLIKASI PELAPORAN BEBAN GI BERBASIS WEB P3BS
                          (2015)<br><br>
                        <LI> PT. PLN (Persero) P3B Sumatera<br>WEBSITE P3B SUMATERA (2015)<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali <br>PENGEMBANGAN APLIKASI AMR BIDANG OPERASI (2015)<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali <br>PENGEMBANGAN APLIKASI SIMPATIK (2015)<br><br>
                        <LI>PT. PLN (Persero) P3B Jawa Bali <br>PENGADAAN APLIKASI FOIS TI (2015)<br><br>
                        <LI>PT. PLN (Persero)<br>Aplikasi PDKB (2016)<br>Aplikasi PDKB<br><br>
                        <LI>PT. PLN (Persero)<br>APLIKASI SIMKPNAS (2016)<br>APLIKASI SIMKPNAS<br><br>
                        <LI>PT. PLN (Persero)<br>PENGEMBANGAN APLIKASI EAM LEGACY TRANSMISI TERPUSAT
                          (2016)<br>PENGEMBANGAN APLIKASI EAM LEGACY TRANSMISI TERPUSAT<br><br>
                        <LI>PT. PLN (Persero)<br>Pengembangan Aplikasi SIMKP 2017 Tahap 2(2017)<br>Pengembangan Aplikasi
                          SIMKP 2017 Tahap 2<br><br>
                        <LI>PT. PLN (Persero)<br>Pengembangan Aplikasi PPA HDKP setelmen (2017)<br>Pengembangan Aplikasi
                          PPA HDKP setelmen<br><br>
                        <LI>PT. PLN (Persero)<br>Pengembangan Aplikasi AMR (2017)<br>Pengembangan Aplikasi AMR <br><br>
                        <LI>PT. PLN (Persero)<br>Aplikasi Transaksi Tenaga Listrik (2017 - 2018)<br>Aplikasi Transaksi
                          Tenaga Listrik<br><br>
                        <LI>PT. PLN (Persero) P2B<br>Aplikasi Mobile Dashboard Informasi Pembangkitan (2018)<br>Aplikasi
                          Mobile Dashboard Informasi Pembangkitan<br><br>
                        <LI>PT. PLN (Persero)<br>Aplikasi PDKB Tegangan Menengah dan Tegangan Tinggi (2018)<br>Aplikasi
                          PDKB Tegangan Menengah dan Tegangan Tinggi<br><br>
                        <LI>Kementrian Keuangan<br>Aplikasi UMi (2018)<br>Aplikasi UMi<br><br>
                        <LI>Kementrian Komunikasi dan Informatika<br>Aplikasi Mobile Dashboard (2018)<br>Aplikasi Mobile
                          Dashboard<br><br>
                        <LI>PT. PLN (Persero) P2B<br>Maintenance Aplikasi Mobile(2018)<br>Maintenance Aplikasi
                          Mobile<br><br>
                        <LI>PT. PLN (Persero) P2B<br>Pengembangan Aplikasi Evaluasi Operasi Sistem Jawa Bali
                          (2018)<br>Maintenance Aplikasi Evaluasi Operasi Sistem Jawa Bali<br><br>
                        <LI>PT. PLN (Persero) P2B<br>Sistem Backup Database Sistem Operasi Jawa Bali (2018)<br>Sistem
                          Backup Database Sistem Operasi Jawa Bali<br><br>
                      </OL>

                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div><!--features icon wrap-->
        </div>
        <!--features col-->
        <!--container-->
  </section><!--about section end-->


  <!--team section end-->








  
  
  
  <!--call to action-->


  <section id="contact" class="section-padding">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 col-sm-offset-2">
          <div class="row contact-details">
            <div class="col-sm-4 margin-bottom30 text-center">
              <i class="ion-ios-location-outline"></i>
              <!--<h4>Jakarta, Indonesia</h4>-->
              <a href="https://maps.app.goo.gl/MfrX23NKbQJew2o79" style="color:white;">
                <h4>Jakarta, Indonesia</h4>
              </a>
            </div>
            <div class="col-sm-4 margin-bottom30 text-center">
              <i class="ion-ios-email-outline"></i>
              <a href="https://mail.google.com/mail/u/0/?view=cm&tf=1&fs=1&to=webcenter.indonesia@gmail.com"
                style="color:white;">
                <h4>webcenter.indonesia@gmail.com</h4>
              </a>
            </div>
            <div class="col-sm-4 margin-bottom30 text-center">
              <i class="ion-ios-telephone-outline"></i>
              <h4>(+62-21)-428-77363</h4>
            </div>
          </div><!--contact details-->
        </div>
      </div>
      
    </div>
  </section><!--contact section end-->

  <footer class="footer" style="background-color: #E61920; padding:  37px">
    <div class="container text-center">
      <span class="alo" style="font-weight: bold">WebCenter Technologies, Inc</span>
      
      <span style="color: white"> Copyright &copy; 1998 - </span> <span id="tahunterkini" style="color: white;"></span>
      <span style="color: white;">WebCenter Technologies, Inc</span>

    </div>
  </footer>
  <script>
    const d = new Date();
    let year = d.getFullYear();
    document.getElementById("tahunterkini").innerHTML = year;
  </script>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="<?php echo e(asset('js/jquery.min.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('js/moderniz.min.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('js/jquery.easing.1.3.js')); ?>" type="text/javascript"></script>
  <!-- bootstrap js-->
  <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/jquery.flexslider-min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/parallax.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/jquery.prettyPhoto.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/jqBootstrapValidation.js')); ?>"></script>
  <!--revolution slider scripts-->
  <script src="<?php echo e(asset('rs-plugin/js/jquery.themepunch.tools.min.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('rs-plugin/js/jquery.themepunch.revolution.min.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('js/template.js')); ?>" type="text/javascript"></script>

</body>

</html><?php /**PATH D:\Companyprofile\resources\views/listproject.blade.php ENDPATH**/ ?>